import sys, json
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

def read_in():
    lines = sys.stdin.readlines()
    return json.loads(lines[0])

def main():
    lines = read_in()
    # x is a data frame
    x = pd.read_csv('C:/Users/marut/Downloads/dataset_dsa.csv')
    x = x.replace(np.nan, 100)
    feature_columns = []

    z = x['Sector'].drop_duplicates()
    for i, j in enumerate(z):
        x['Sector'] = x['Sector'].replace(j, i)

    # z contains only - rural and urban - first occurance
    
    feature_df = x[['Sector','Time required', 'Budget','Salary for skilled workers', 'Salary for unskilled workers']]
    target1 = x['Skilled workers']
    target2 = x['Unskilled workers']
    clf = RandomForestRegressor()
    clf1 = RandomForestRegressor()
    clf.fit(feature_df, target1)
    clf1.fit(feature_df, target2)
    Feature = [lines[0], lines[1],lines[2],lines[3],lines[4]]
    ans=clf.predict([Feature])
    ans1=clf1.predict([Feature])
    print("Skilled workers required :",round(ans[0]),"and Unskilled workers required",round(ans1[0]))
if __name__ == '__main__':
    main()
