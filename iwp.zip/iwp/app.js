const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const ejs = require("ejs");
const app = express();
const encrypt=require("mongoose-encryption");
const {PythonShell} = require("python-shell");

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
mongoose.connect("mongodb://localhost:27017/jobDB", {useNewUrlParser: true,useUnifiedTopology: true});
app.use(express.static("public"));

var opt=0;
var p,q;
var use_email;
var use_pid;

const appSchema = {
  fname: String,
  lname: String,
  email: String,
  pno: Number,
  sector: String,
  dob:String,
  qlf: String,
  wrkexp: String,
  state:String,
  place:String,
  pid:String
};

const contractSchema={
  fname: String,
  lname: String,
  email: String,
  pno: Number,
  dob:String,
  cname:String,
  cnumber:Number,
  cemail:String,
  caddress:String,
  cwork:String,
  cexp:String,
  upass:String
};


const contractor_login_schema={
  mail:String,
  pass:String
};

const adminSchema={
    id:Number,
    password:String
};

const projSchema={
    cemail:String,
    cname:String,
    email:String,
    compno:Number,
    compaddr:String,
    projname:String,
    pwork:String,
    pdescription:String,
    lastdate:String,
    budget:String,
    swr:String,
    uswr:String
};

const adminsigninSchema={
    fname:String,
    lname:String,
    email:String,
    id:Number,
    pass:String
};

const job = mongoose.model("job", appSchema);
const contractor=mongoose.model("contractor",contractSchema);
const admins=mongoose.model("admins",adminSchema);
const clogin=mongoose.model("clogin",contractor_login_schema);
const proj=mongoose.model("proj",projSchema);
const adminsign=mongoose.model("adminsign",adminsigninSchema);

app.get("/",function(req,res){
    res.render("index");
});

app.get("/apply",function(req,res){
      /*if(opt==0){
      job.find(function(err,ppl){
              res.render("applications", {pname:ppl});
        });}
      else {
        sen=[];
        opt=0;
        job.find(function(err,ppl){
          ppl.forEach(function(pp){
            if(pp.sector==p && pp.qlf==q)
            {
              sen.push(pp);
            }
          });
          res.render("applications",{pname:sen});
        })
      }
      res.redirect("applications");*/

});

app.get("/admin-signin",function(req,res){
  res.render("admin-signin");
});



app.get("/budget",function(req,res){
  res.render("budget");
});

app.get("/time",function(req,res){
  res.render("Time");
});

app.get("/workforce",function(req,res){
  res.render("workforce");
});

app.get("/jobportal",function(req,res){
  res.render("jobportal");
});

app.get("/login",function(req,res){
  res.render("login");
});

app.get("/signin",function(req,res){
  res.render("signin");
});

app.get("/admin_login",function(req,res){
    res.render("admin_login");
});

app.get("/admin",function(req,res){

});

app.get("/choice",function(req,res){
    res.render("choice");
});

app.get("/choice1",function(req,res){
    res.render("choice1");
});

app.get("/test",function(req,res){
  res.render("test");
})

app.get("/choice2",function(req,res){
  sending=[];
  proj.find(function(err,p){
    p.forEach(function(pro){
      if(pro.cemail==use_email)
      {
        sending.push(pro);
      }
    });
    res.render("choice2",{catching:sending});
});
});

app.get("/projects",function(req,res){
  projects=[];
  proj.find(function(err,p){
    p.forEach(function(pro){
        projects.push(pro);
    });
    res.render("projects",{pros:projects});
});
});

app.post("/choice2",function(req,res){
  var ppl2=[];
  var pid1=req.body.pid;
  proj.findOne({_id:pid1},function(err,fid){
  job.find({pid:fid._id},function(err,ppl1){
          res.render("applications", {pname:ppl1,projname:fid.projname});
    });
  });
});

app.post("/projects",function(req,res){
   use_pid=req.body.pid;
  proj.findOne({_id:use_pid},function(err,fid){
      res.redirect("jobportal");
  });
});

app.post("/choice11",function(req,res){
    res.render("choice1");
});

app.post("/choice22",function(req,res){
    res.redirect("choice2");
});

app.post("/choice1",function(req,res){
    var cname=req.body.cname;
    var cemail=req.body.cemail;
    var cpno=req.body.cpno;
    var caddr=req.body.caddr;
    var pname=req.body.pname;
    var cwork=req.body.cwork;
    var pdes=req.body.pdes;
    var ld=req.body.ld;
    var pb=req.body.pb;
    var sw=req.body.sw;
    var usw=req.body.usw;
    var success="Your Project is succefully registered";
    const project=new proj({cemail:use_email,cname:cname,email:cemail,compno:cpno,compaddr:caddr,projname:pname,pwork:cwork,pdescription:pdes,lastdate:ld,budget:pb,swr:sw,uswr:usw});
    project.save();
    res.render("choice1",{msg1:success});
});

app.post("/admin-signin",function(req,res){
    var fname=req.body.fname;
    var lname=req.body.lname;
    var email=req.body.email;
    var id=req.body.uname;
    var pass=req.body.psw;
    var success="Registered successfully";
    var fail="ID already existed";
    var fail1="Already Registered";
    admins.findOne({id:id},function(err,found){
      if(found){
        res.render("admin-signin",{msg:fail});
      }
      else{
        adminsign.findOne({id:id},function(err,found1){
            if(found1){
              res.render("admin-signin",{msg:fail1});
            }
            else{
              const new_admin=new adminsign({fname:fname,lname:lname,email:email,id:id,pass:pass});
              new_admin.save();
              res.render("admin-signin",{msg:success});
            }
        });
      }
    });
});

app.post("/admin",function(req,res){
    var a=req.body.contract_email;
    var email_error="This email address is not registered";
    contractor.findOne({email:a},function(err,foundmail){
      if(!foundmail){
        res.render("admin",{msg:email_error});
      }
      else{
      const add=new clogin({mail:a,pass:foundmail.upass});
      add.save();
      res.render("admin");}
    });
});

app.post("/admin_choice",function(req,res){
  res.render("admin");
});

app.post("/admin1",function(req,res){
    var a=req.body.admin_id;
    var email_error="This ID is not registered";
    adminsign.findOne({id:a},function(err,foundmail){
      if(!foundmail){
        res.render("admin",{msg1:email_error});
      }
      else{
      const add=new admins({id:a,password:foundmail.pass});
      add.save();
      res.render("admin");}
    });
});

app.post("/login",function(req,res){
    var u=req.body.uname;
    var p=req.body.psw;
    var email_msg="User Doesn't Exist";
    var password_msg="Password is incorrect";
    clogin.findOne({mail:u},function(err,contractor){
      if(!contractor){
        res.render("login", {msg:email_msg});
      }
      else{
        if(contractor.pass==p){
          use_email=u;
          res.redirect("choice");
        }
        else{
          res.render("login", {msg:password_msg});
        }
      }
    });
});

app.post("/admin_login",function(req,res){
    var id=req.body.uname;
    var pass=req.body.psw;
    var id_error="Admin ID doesn't exist";
    var password_msg="Password is incorrect";
    admins.findOne({id: id}, function(err, foundId){
      if(!foundId)
      {
        res.render("admin_login",{msg:id_error});
      }
      else{
      if(foundId.password==pass){
        adminss=[];
        contractorss=[];
        contractor.find(function(err,qq){
          adminsign.find(function(err,pp){
            res.render("admin_choice",{pros:qq,pros1:pp});
          });
          });
      }
      else{
        res.render("admin_login",{msg:password_msg});
      }
}
});
});

app.post("/jobportal",function(req,res){
  var f=req.body.fname;
  var l=req.body.lname;
  var e=req.body.emails;
  var d=req.body.dob;
  var p=req.body.pno;
  var q=req.body.qualification;
  var w=req.body.work;
  var s=req.body.sector;
  var st=req.body.state;
  var pl=req.body.place;
  var success="Application Registered";
  const entry = new job({pid:use_pid,fname:f,lname:l,email:e,pno:p,sector:s,qlf:q,wrkexp:w,state:st,place:pl,dob:d});
  entry.save();
  res.redirect("/jobportal");
});

app.post("/signin",function(req,res){
  var f=req.body.fname;
  var l=req.body.lname;
  var e=req.body.emails;
  var d=req.body.dob;
  var p=req.body.pno;
  var cn=req.body.cname;
  var cp=req.body.cpno;
  var ce=req.body.cemails;
  var cadd=req.body.caddr;
  var cw=req.body.cwork;
  var cexp=req.body.cexp;
  var cu=req.body.uname;
  var pa=req.body.psw;
  var existed="Account is already existed";
  var already="You have already registered";
  var success="Your account is registered successfully.\nAfter verifying the details account will be created.\nYou will get an email after account is created";
  clogin.findOne({mail:e},function(err,found1){
    if(found1){
      res.render("signin",{msg:existed});
    }
    else{
      contractor.findOne({email:e},function(err,found){
              if(found){res.render("signin",{msg:already});}
              else{
                const ent = new contractor({fname:f,lname:l,email:e,pno:p,dob:d,cname:cn,cnumber:cp,cemail:ce,caddress:cadd,cwork:cw,cexp:cexp,upass:pa});
                ent.save();
                res.render("signin",{msg1:success});
              }
        });
    }
  });
});

app.post("/applications",function(req,res){
  p=req.body.place;
  q=req.body.qualification;
  if(p=="all" && q=="all")
  {
    opt=0;
    res.redirect("/apply");
  }
  else
  {
    opt=1;
    res.redirect("/apply");
  }
});

app.post("/budget",function(req,res){
  var sec=req.body.sector;
  var t = req.body.time;
  var s = req.body.sworkers;
  var us = req.body.usworkers;
  if(!s){s=100;}
  if(!t){t=3;}
  if(!us){us=100;}
  var sector;
  if(sec=="Rural"){
    sector=0;
  }
  else{
    sector=1;
  }
  var pyshell = new PythonShell('budgetfind.py');
  pyshell.send(JSON.stringify([sector,t,s,us]));
  pyshell.on('message', function (message) {
    res.render('budget', {msg: message});
});
pyshell.end(function (err) {
    if (err){
        throw err;
    };
});
});

app.post("/Time",function(req,res){
  var sec=req.body.sector;
  var t = req.body.budget;
  var s = req.body.sworkers;
  var us = req.body.usworkers;
  var sector;
  if(!s){s=100;}
  if(!t){t=100;}
  if(!us){us=100;}
  if(sec=="Rural"){
    sector=0;
  }
  else{
    sector=1;
  }
  var pyshell = new PythonShell('timefind.py');
  pyshell.send(JSON.stringify([sector,t,s,us]));
  pyshell.on('message', function (message) {
    res.render('Time', {msg: message});
});
pyshell.end(function (err) {
    if (err){
        throw err;
    };
});
});

app.post("/workforce",function(req,res){
  var s=req.body.sector;
  var t = req.body.time;
  var b = req.body.budget;
  var ss = req.body.ssworkers;
  var us = req.body.susworkers;
  if(!ss){ss=50000;}
  if(!t){t=3;}
  if(!b){b=100;}
  if(!us){us=2000;}
  var sec;
  if(s=="Rural"){
    sec=0;
  }
  else{
    sec=1;
  }
  var pyshell = new PythonShell('workfind.py');
  pyshell.send(JSON.stringify([sec,t,b,ss,us]));
  pyshell.on('message', function (message) {
 res.render('workforce', {msg: message});
});
pyshell.end(function (err) {
    if (err){
        throw err;
    };
});
});

app.listen(3000,function(){
  console.log("Server started in port 3000");
});
