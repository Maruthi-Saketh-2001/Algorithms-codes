import sys, json
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

def read_in():
    lines = sys.stdin.readlines()
    return json.loads(lines[0])

def main():
    lines = read_in()
    # x is a data frame
    x = pd.read_csv('C:/Users/marut/Downloads/dataset.csv')
    x = x.replace(np.nan, 100)
    feature_columns = []

    z = x['Sector'].drop_duplicates()
    for i, j in enumerate(z):
        x['Sector'] = x['Sector'].replace(j, i)

    # z contains only - rural and urban - first occurance
    # enumerate function output:
    # 1, rural
    # 2, urban


    feature_df = x[['Sector','Time required', 'Skilled workers', 'Unskilled workers']]
    target = x['Budget']

    clf = RandomForestRegressor()
    clf.fit(feature_df, target)

    Feature = [lines[0], lines[1],lines[2],lines[3]]
    ans=clf.predict([Feature])
    print("Budget required(in crores)", round(ans[0]))
if __name__ == '__main__':
    main()
