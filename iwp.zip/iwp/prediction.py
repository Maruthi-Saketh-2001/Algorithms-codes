import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
# x is a data frame
x = pd.read_csv('C:/Users/marut/Downloads/dataset_dsa.csv')
x = x.replace(np.nan, 100)
feature_columns = []

z = x['Sector'].drop_duplicates()
for i, j in enumerate(z):
    x['Sector'] = x['Sector'].replace(j, i)

# z contains only - rural and urban - first occurance
z = x['place of project'].drop_duplicates()
# enumerate function output:
# 1, rural
# 2, urban

for i, j in enumerate(z):
    x['place of project'] = x['place of project'].replace(j,i)

feature_df = x[['Sector', 'Budget', 'Salary for skilled workers', 'Salary for unskilled workers']]
target1= x['Skilled workers']
target2= x['Unskilled workers']

test_sector = input("Enter 0 for rural areas and 1 for urban areas")
test_budget = input("Enter budget amount(in Crores)")
test_skilled_salary = input("Enter salary of skilled worker(in rupees/month):")
test_unskilled_salary = input("Enter salary of unskilled worker(in rupees/month):")

clf = RandomForestRegressor()
clf.fit(feature_df, target1)
Feature = [test_sector, test_budget, test_skilled_salary, test_unskilled_salary]
print("Time required(in years)", clf.predict([Feature]))

clf.fit(feature_df, target1)
print("Time required(in years)", clf.predict([Feature]))